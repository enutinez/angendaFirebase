package com.example.schudulecontac;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class Data {
        FirebaseDatabase firebaseDatabase;
        DatabaseReference databaseReference;
    private static ArrayList<Contact> Contacts = new ArrayList<>();
    public static void Save (Contact c){ Contacts.add(c);}
    public static ArrayList<Contact> Get(){return Contacts;}

}
