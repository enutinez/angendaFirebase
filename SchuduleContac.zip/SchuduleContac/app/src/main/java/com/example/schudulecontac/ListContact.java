package com.example.schudulecontac;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.schudulecontac.Contact;
import com.example.schudulecontac.ContactDetail;
import com.example.schudulecontac.Data;
import com.example.schudulecontac.R;

import java.util.ArrayList;

public class ListContact extends AppCompatActivity {

    private ListView LV;
    private ArrayList<Contact> Contacts;
    private ArrayList<String> ContactName;
    private Intent In;
    private TextView TxtNoResults;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.contact_list);

        LV = (ListView) findViewById(R.id.LVContacts);
        TxtNoResults = (TextView)findViewById(R.id.TxtNoResults);
        Contacts = Data.Get();
        ContactName = new ArrayList<String>();

        TxtNoResults.setVisibility(View.INVISIBLE);


        if (Contacts.size() > 0){
            LV.setVisibility(View.VISIBLE);
            TxtNoResults.setVisibility(View.INVISIBLE);


            for (int i = 0; i < Contacts.size(); i++) {
                ContactName.add(Contacts.get(i).getName() + " " + Contacts.get(i).getLastName());

            }

        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ContactName);
        LV.setAdapter(adapter);




        LV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                In = new Intent(ListContact.this, ContactDetail.class);
                In.putExtra("position", position);
                startActivity(In);
            }
        });

    }
}
