package com.example.schudulecontac;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CreateContact extends AppCompatActivity {
    private EditText Name, LastName, Phone, Cellphone;
    private Resources Resources;
    private ArrayList<Contact> contacts;
    private FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;




    @Override
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.create_contact);

        Name = (EditText)findViewById(R.id.TxtName);
        LastName = (EditText)findViewById(R.id.TxtLastName);
        Phone = (EditText)findViewById(R.id.TxtPhone);
        Cellphone = (EditText)findViewById(R.id.TxtCellphone);

        Resources = this.getResources();
        contacts = Data.Get();
        inicializarFirebase();
    }

    private void inicializarFirebase() {
        FirebaseApp.initializeApp(this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }
    public FirebaseDatabase getFirebaseDatabase() {
        return firebaseDatabase;
    }

    public void Save(View view){
        String ID, NameV, LastNameV, PhoneV, CellphoneV;
        ID = (contacts.size()+1) + "";
        NameV = Name.getText().toString();
        LastNameV = LastName.getText().toString();
        PhoneV = Phone.getText().toString();
        CellphoneV = Cellphone.getText().toString();
        if (NameV.equals("")|| LastNameV.equals("") || PhoneV.equals("") || CellphoneV.equals("")){
            validar();
        }else {
            Contact C = new Contact(ID, NameV, LastNameV, PhoneV, CellphoneV);
            cargarContactoFirebase(NameV, LastNameV, PhoneV, CellphoneV);
            C.SaveContact();
            Toast.makeText(this, R.string.done, Toast.LENGTH_LONG).show();

            limpiarCajas();
        }
    }
    private void cargarContactoFirebase(String nameV, String lastNameV, String phoneV, String cellphoneV) {
        Map<String, Object> datosContact = new HashMap<>();
        datosContact.put("Name", nameV);
        datosContact.put("LastName", lastNameV);
        datosContact.put("Phone", phoneV);
        datosContact.put("Cellphon", cellphoneV);

        databaseReference.child("Contact").push().setValue(datosContact);
    }

    private void limpiarCajas() {
        Name.setText("");
        LastName.setText("");
        Phone.setText("");
        Cellphone.setText("");
    }

    private void validar() {
        String nombre = Name.getText().toString();
        String apellido = LastName.getText().toString();
        String telefono = Phone.getText().toString();
        String celular = Cellphone.getText().toString();
        if (nombre.equals(" ")){
            Name.setError("Required");
        }

        if (apellido.equals("")){
            LastName.setError("Required");
        }
        if (telefono.equals("")){
            Phone.setError("Required");
        }
        if (celular.equals(" ")){
            Cellphone.setError("Required");
        }
    }


}


